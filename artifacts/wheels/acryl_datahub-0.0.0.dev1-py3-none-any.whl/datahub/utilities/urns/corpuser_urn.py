from datahub.metadata.urns import CorpUserUrn as CorpuserUrn  # noqa: F401
