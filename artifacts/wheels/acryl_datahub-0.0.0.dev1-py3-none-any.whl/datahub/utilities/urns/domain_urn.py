from datahub.metadata.urns import DomainUrn  # noqa: F401
