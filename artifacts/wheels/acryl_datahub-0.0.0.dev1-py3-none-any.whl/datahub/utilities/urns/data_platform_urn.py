from datahub.metadata.urns import DataPlatformUrn  # noqa: F401
