# Datahub Airflow Plugin

See [the DataHub Airflow docs](https://datahubproject.io/docs/lineage/airflow) for details.

