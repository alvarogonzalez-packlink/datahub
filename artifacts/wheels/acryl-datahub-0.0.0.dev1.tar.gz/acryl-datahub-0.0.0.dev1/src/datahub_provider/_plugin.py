from datahub_airflow_plugin.datahub_plugin import DatahubPlugin

__all__ = ["DatahubPlugin"]
