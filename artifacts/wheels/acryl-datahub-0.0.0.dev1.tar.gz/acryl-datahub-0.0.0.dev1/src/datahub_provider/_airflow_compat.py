from datahub_airflow_plugin._airflow_compat import AIRFLOW_PATCHED

__all__ = ["AIRFLOW_PATCHED"]
