from datahub_airflow_plugin._lineage_core import DatahubBasicLineageConfig

__all__ = ["DatahubBasicLineageConfig"]
