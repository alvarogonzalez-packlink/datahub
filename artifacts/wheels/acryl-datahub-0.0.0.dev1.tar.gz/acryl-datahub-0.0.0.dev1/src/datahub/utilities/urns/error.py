class InvalidUrnError(Exception):
    pass
